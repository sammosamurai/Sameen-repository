# JavaPrework

This repository provides a sample baseline of the required setup for exercises within the SMS Management and Technology Agile Programming course trials.

To get started clone the repo:
```
git clone https://github.com/HonourSystems/JavaPrework.git
```
And do the following:
- Implement the calcuate function for PrimeCalculator so that the tests pass.
- Write the test for RedisPublishingStringClient using Mockito to enable testing without the database.
