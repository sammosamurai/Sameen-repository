package com.smsmt.ae.programming.prework;

public class PrimeGenerator {
    public static int generate(int primeIndex) {
        return -1;
    }
}
