package com.smsmt.ae.programming.prework;

import org.junit.Test;

import static junit.framework.TestCase.fail;

public class TestRedisStringClient {

    @Test
    public void TestPublishOnSet() {
        // TODO: Test that the RedisPublishingStringClient publishes the key value when calling set.
        fail();
    }

}
